import React, { useMemo, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import Back from "../assets/Back.svg";
import Secure from "../assets/secure.webp";
import "./OrderSummary.css";

const readCart = () => { try { const x=JSON.parse(localStorage.getItem("checkout_cart") || localStorage.getItem("cart_items") || "[]"); return Array.isArray(x)?x:[]; } catch { return []; } };

export default function OrderSummary() {
  const navigate = useNavigate();
  const [items, setItems] = useState(readCart);
  const keyOf = x => String(x.md5_id ?? x.id ?? "")+"|"+(x.color||"")+"|"+(x.size||"")+"|"+(x.storage||"");
  const save = next => { setItems(next); localStorage.setItem("cart_items",JSON.stringify(next)); localStorage.setItem("checkout_cart",JSON.stringify(next)); window.dispatchEvent(new Event("cartUpdated")); };
 const change = (item, d) => {
  let n = items
    .map((x) =>
      keyOf(x) === keyOf(item)
        ? {
            ...x,
            qty: Math.max(
              0,
              Math.min(99, (Number(x.qty) || 1) + d)
            ),
          }
        : x
    )
    .filter((x) => (Number(x.qty) || 0) > 0);

  save(n);
};
  const totals=useMemo(()=>items.reduce((a,x)=>{const q=Number(x.qty)||1,p=Number(x.selling_price??x.price)||0,m=Number(x.mrp??x.cancelprice??p)||p;a.pay+=p*q;a.mrp+=m*q;a.qty+=q;return a},{pay:0,mrp:0,qty:0}),[items]);
  const discount=Math.max(0,totals.mrp-totals.pay);
  const goPayment=()=>{localStorage.setItem("checkout_total",String(totals.pay));localStorage.setItem("checkout_cart",JSON.stringify(items));navigate('/payment');};

  const money = value => '₹' + Number(value).toLocaleString('en-IN', { maximumFractionDigits: 2 });
  return (
    <main className="summary-page">
      <header className="summary-header"><Link to="/cart" aria-label="Back to cart"><img src={Back} alt="" /></Link><h1>Order Summary</h1></header>
      <ol className="summary-steps" aria-label="Checkout progress">{['Address', 'Order Summary', 'Payment'].map((label, index) => <li key={label} className={index <= 1 ? 'active' : ''} aria-current={index === 1 ? 'step' : undefined}><span>{index === 0 ? '✓' : index + 1}</span><small>{label}</small></li>)}</ol>
      <div className="summary-layout">
        <div className="summary-content">
          <section className="summary-address"><div><h2>Deliver to: <strong>{localStorage.getItem('fname') || 'Select delivery address'}</strong> <small>{localStorage.getItem('addressType') || 'Home'}</small></h2><p>{localStorage.getItem('address')}</p><p>{localStorage.getItem('mobile')}</p></div><Link to="/address">Change</Link></section>
          <section className="summary-products" aria-label="Order items">
            {!items.length && <div className="summary-empty"><h2>Your cart is empty</h2><p>Add products to continue with your order.</p><Link to="/">Continue shopping</Link></div>}
            {items.map(item => { const p = Number(item.selling_price ?? item.price) || 0; const m = Number(item.mrp ?? item.cancelprice ?? p) || p; const off = m > p ? Math.round((m - p) / m * 100) : 0;
              return <article className="summary-product" key={keyOf(item)}>
                <div className="summary-image"><img src={item.img1 || item.image?.[0]} alt={item.name || item.title || 'Product'} /><div className="summary-quantity"><button type="button" aria-label={'Decrease quantity of ' + (item.name || item.title)} onClick={() => change(item, -1)}>−</button><span aria-live="polite">{Number(item.qty) || 1}</span><button type="button" disabled={(Number(item.qty) || 1) >= 99} aria-label={'Increase quantity of ' + (item.name || item.title)} onClick={() => change(item, 1)}>+</button></div></div>
                <div className="summary-product-info"><h2>{item.name || item.title}</h2><p className="summary-variant">{[item.color, item.storage, item.size].filter(Boolean).join(' · ')}</p><div className="summary-product-price">{m > p && <del>{money(m)}</del>}<strong>{money(p)}</strong>{off > 0 && <span>{off}% off</span>}</div><p className="summary-delivery">Delivery charges <strong>FREE</strong></p><button type="button" className="summary-remove" onClick={() => save(items.filter(x => keyOf(x) !== keyOf(item)))}>REMOVE</button></div>
              </article>;
            })}
          </section>
        </div>
        <aside className="summary-aside">
          <section className="summary-prices" id="summary-price-details"><h2>PRICE DETAILS</h2><dl><div><dt>Price ({totals.qty} {totals.qty === 1 ? 'item' : 'items'})</dt><dd>{money(totals.mrp)}</dd></div><div><dt>Discount</dt><dd className="summary-green">− {money(discount)}</dd></div><div><dt>Delivery Charges</dt><dd className="summary-green">FREE</dd></div><div className="summary-total"><dt>Total Amount</dt><dd>{money(totals.pay)}</dd></div></dl>{discount > 0 && <p className="summary-saving">You will save {money(discount)} on this order</p>}</section>
          <p className="summary-security"><img src={Secure} alt="" />Your order total will be carried forward to payment.</p>
        </aside>
      </div>
      <footer className="summary-footer"><div><strong>{money(totals.pay)}</strong><a href="#summary-price-details">View price details</a></div><button type="button" disabled={!items.length} onClick={goPayment}>CONTINUE</button></footer>
    </main>
  );
}
